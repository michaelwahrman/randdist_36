"use strict"; 

var glayer = (function() {

  var a = 0;
  var b = function() {
      return a;
  }

  return {
  
    increment: function() {
    },

    decrement: function() {
    }

  };

})();

console.log("glayer defined");


    
